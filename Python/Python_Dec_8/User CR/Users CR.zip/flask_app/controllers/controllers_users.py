from types import MethodType
from flask_app import app
from flask import render_template, redirect, request
from flask_app.models import model_users

@app.route('/')
def index():
    return redirect('/users')

@app.route('/users')
def users_show():
    return render_template("users.html", users=model_users.User.get_all())

@app.route('/users/new_user')
def new_user():
    return render_template("new_user.html")

@app.route('/users/create', methods=['post'])
def create():
    print(request.form)
    model_users.User.save(request.form)
    return redirect('/users')